
import 'package:flutter/material.dart';
import '../services/api_service.dart';

class BiltyListScreen extends StatefulWidget {
  final Map<String, dynamic> user;
  const BiltyListScreen({super.key, required this.user});

  @override
  State<BiltyListScreen> createState() => _BiltyListScreenState();
}

class _BiltyListScreenState extends State<BiltyListScreen> {
  List<Map<String, dynamic>> list = [];

  Future<void> _load() async {
    final data = await Api.biltiesList();
    setState(() => list = data.cast<Map<String, dynamic>>());
  }

  Future<void> _addOrEdit({Map<String, dynamic>? existing}) async {
    final vendor = TextEditingController(text: existing?['vendor'] ?? '');
    final vehicle = TextEditingController(text: existing?['vehicle'] ?? '');
    final goods = TextEditingController(text: existing?['goods'] ?? '');
    final fromCity = TextEditingController(text: existing?['from_city'] ?? '');
    final toCity = TextEditingController(text: existing?['to_city'] ?? '');
    final km = TextEditingController(text: existing?['km']?.toString() ?? '');
    final amount = TextEditingController(text: existing?['amount']?.toString() ?? '');
    final notes = TextEditingController(text: existing?['notes'] ?? '');

    await showDialog(
      context: context,
      builder: (_) => AlertDialog(
        title: Text(existing == null ? 'Add Bilty / Vendor' : 'Edit Bilty'),
        content: SingleChildScrollView(
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              TextField(controller: vendor, decoration: const InputDecoration(labelText: 'Vendor')),
              TextField(controller: vehicle, decoration: const InputDecoration(labelText: 'Vehicle')),
              TextField(controller: goods, decoration: const InputDecoration(labelText: 'Goods')),
              Row(children: [
                Expanded(child: TextField(controller: fromCity, decoration: const InputDecoration(labelText: 'From'))),
                const SizedBox(width: 8),
                Expanded(child: TextField(controller: toCity, decoration: const InputDecoration(labelText: 'To'))),
              ]),
              Row(children: [
                Expanded(child: TextField(controller: km, keyboardType: TextInputType.number, decoration: const InputDecoration(labelText: 'KM'))),
                const SizedBox(width: 8),
                Expanded(child: TextField(controller: amount, keyboardType: TextInputType.number, decoration: const InputDecoration(labelText: 'Amount (PKR)'))),
              ]),
              TextField(controller: notes, decoration: const InputDecoration(labelText: 'Notes')),
            ],
          ),
        ),
        actions: [
          TextButton(onPressed: () => Navigator.pop(context), child: const Text('Cancel')),
          FilledButton(
            onPressed: () async {
              final data = {
                if (existing?['id'] != null) 'id': existing!['id'].toString(),
                'vendor': vendor.text,
                'vehicle': vehicle.text,
                'goods': goods.text,
                'from_city': fromCity.text,
                'to_city': toCity.text,
                'km': km.text,
                'amount': amount.text,
                'notes': notes.text,
                'created_by': widget.user['email'] ?? '',
              };
              await Api.biltiesSave(data);
              if (!mounted) return;
              Navigator.pop(context);
              _load();
            },
            child: const Text('Save'),
          ),
        ],
      ),
    );
  }

  Future<void> _delete(int id) async {
    final role = widget.user['role'] ?? 'staff';
    if (role != 'admin') return;
    await Api.biltiesDelete(id);
    _load();
  }

  @override
  void initState() {
    super.initState();
    _load();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Bilty / Vendor Records')),
      floatingActionButton: FloatingActionButton(onPressed: () => _addOrEdit(), child: const Icon(Icons.add)),
      body: ListView.separated(
        itemBuilder: (_, i) {
          final b = list[i];
          return ListTile(
            leading: const Icon(Icons.receipt_long),
            title: Text('${b['vendor']} — ${b['vehicle']}'),
            subtitle: Text('${b['from_city']} ➜ ${b['to_city']} • KM ${b['km']} • PKR ${b['amount']}'),
            trailing: Row(
              mainAxisSize: MainAxisSize.min,
              children: [
                IconButton(onPressed: () => _addOrEdit(existing: b), icon: const Icon(Icons.edit)),
                if ((widget.user['role'] ?? 'staff') == 'admin') IconButton(onPressed: () => _delete(b['id'] as int), icon: const Icon(Icons.delete)),
              ],
            ),
          );
        },
        separatorBuilder: (_, __) => const Divider(height: 0),
        itemCount: list.length,
      ),
    );
  }
}
