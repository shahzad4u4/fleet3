
import 'dart:convert';
import 'package:http/http.dart' as http;

/// Hosted API base
const String apiBase = "https://hslogistics.pk/api";

class Api {
  static Future<Map<String, dynamic>> _post(String path, Map<String, dynamic> body) async {
    final uri = Uri.parse('$apiBase/$path');
    final res = await http.post(uri, body: body);
    if (res.statusCode != 200) {
      throw Exception('HTTP ${res.statusCode}: ${res.body}');
    }
    final map = json.decode(res.body) as Map<String, dynamic>;
    if (map['ok'] != true) {
      throw Exception(map['error'] ?? 'Unknown API error');
    }
    return map;
  }

  // Auth
  static Future<Map<String, dynamic>> login(String email, String password) async {
    return await _post('api.php', {'action':'login','email':email,'password':password});
  }

  // Payments
  static Future<List<dynamic>> paymentsList() async {
    final r = await _post('api.php', {'action':'payments_list'});
    return r['data'] as List<dynamic>;
  }
  static Future<void> paymentsSave(Map<String, dynamic> data) async {
    await _post('api.php', {'action':'payments_save', ...data});
  }
  static Future<void> paymentsDelete(int id) async {
    await _post('api.php', {'action':'payments_delete','id':id.toString()});
  }

  // Bilties
  static Future<List<dynamic>> biltiesList() async {
    final r = await _post('api.php', {'action':'bilties_list'});
    return r['data'] as List<dynamic>;
  }
  static Future<void> biltiesSave(Map<String, dynamic> data) async {
    await _post('api.php', {'action':'bilties_save', ...data});
  }
  static Future<void> biltiesDelete(int id) async {
    await _post('api.php', {'action':'bilties_delete','id':id.toString()});
  }
}
