
import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import '../services/api_service.dart';
import 'payments_screen.dart';
import 'bilty_list_screen.dart';
import 'about_screen.dart';

class DashboardScreen extends StatefulWidget {
  final Map<String, dynamic> user;
  const DashboardScreen({super.key, required this.user});

  @override
  State<DashboardScreen> createState() => _DashboardScreenState();
}

class _DashboardScreenState extends State<DashboardScreen> {
  double incoming = 0, outgoing = 0;
  final df = NumberFormat("#,##0.##");

  Future<void> _loadTotals() async {
    final list = await Api.paymentsList();
    double inc = 0, out = 0;
    for (final r in list) {
      final type = r['type'] as String? ?? 'incoming';
      final amount = (r['amount'] as num?)?.toDouble() ?? 0;
      if (type == 'incoming') inc += amount; else out += amount;
    }
    setState(() { incoming = inc; outgoing = out; });
  }

  @override
  void initState() {
    super.initState();
    _loadTotals();
  }

  @override
  Widget build(BuildContext context) {
    final role = widget.user['role'] ?? 'staff';
    final name = widget.user['name'] ?? 'User';
    final email = widget.user['email'] ?? '';
    return Scaffold(
      appBar: AppBar(title: const Text('HS Logistics Dashboard')),
      drawer: Drawer(
        child: ListView(
          padding: EdgeInsets.zero,
          children: [
            UserAccountsDrawerHeader(
              currentAccountPicture: const CircleAvatar(child: Icon(Icons.local_shipping)),
              accountName: Text(name),
              accountEmail: Text('$email ($role)'),
            ),
            ListTile(leading: const Icon(Icons.payments), title: const Text('Payments'),
              onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => PaymentsScreen(user: widget.user))).then((_) => _loadTotals())),
            ListTile(leading: const Icon(Icons.receipt_long), title: const Text('Bilty / Vendor'),
              onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => BiltyListScreen(user: widget.user))).then((_) => _loadTotals())),
            ListTile(leading: const Icon(Icons.info_outline), title: const Text('About'),
              onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const AboutScreen()))),
            const Divider(),
            ListTile(leading: const Icon(Icons.logout), title: const Text('Logout'),
              onTap: () => Navigator.of(context).popUntil((route) => route.isFirst)),
          ],
        ),
      ),
      body: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          children: [
            Row(
              children: [
                _statCard('Incoming (PKR)', df.format(incoming), Icons.south_west, Colors.green),
                const SizedBox(width: 12),
                _statCard('Outgoing (PKR)', df.format(outgoing), Icons.north_east, Colors.red),
              ],
            ),
            const SizedBox(height: 16),
            Expanded(
              child: Card(
                elevation: 2,
                child: Center(
                  child: Text('Welcome, $name\nManage Payments and Bilties.', textAlign: TextAlign.center, style: const TextStyle(fontSize: 18)),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Expanded _statCard(String title, String value, IconData icon, Color color) {
    return Expanded(
      child: Card(
        elevation: 2,
        child: Padding(
          padding: const EdgeInsets.all(16),
          child: Row(
            children: [
              Icon(icon, size: 36, color: color),
              const SizedBox(width: 12),
              Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                Text(title, style: const TextStyle(fontWeight: FontWeight.w600)),
                const SizedBox(height: 6),
                Text(value, style: const TextStyle(fontSize: 20)),
              ]),
            ],
          ),
        ),
      ),
    );
  }
}
