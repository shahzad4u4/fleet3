
import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import '../services/api_service.dart';

class PaymentsScreen extends StatefulWidget {
  final Map<String, dynamic> user;
  const PaymentsScreen({super.key, required this.user});

  @override
  State<PaymentsScreen> createState() => _PaymentsScreenState();
}

class _PaymentsScreenState extends State<PaymentsScreen> {
  final df = NumberFormat("#,##0.##");
  List<Map<String,dynamic>> list = [];

  Future<void> _load() async {
    final data = await Api.paymentsList();
    setState(() => list = data.cast<Map<String,dynamic>>());
  }

  Future<void> _addOrEdit({Map<String,dynamic>? existing}) async {
    final party = TextEditingController(text: existing?['party'] ?? '');
    final amount = TextEditingController(text: existing?['amount']?.toString() ?? '');
    final reference = TextEditingController(text: existing?['reference'] ?? '');
    String type = existing?['type'] ?? 'incoming';

    await showDialog(
      context: context,
      builder: (_) => AlertDialog(
        title: Text(existing == null ? 'Add Payment' : 'Edit Payment'),
        content: SingleChildScrollView(
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              TextField(controller: party, decoration: const InputDecoration(labelText: 'Party')),
              DropdownButtonFormField(
                value: type,
                items: const [
                  DropdownMenuItem(value: 'incoming', child: Text('Incoming (Received)')),
                  DropdownMenuItem(value: 'outgoing', child: Text('Outgoing (Paid)')),
                ],
                onChanged: (v) => type = v as String,
                decoration: const InputDecoration(labelText: 'Type'),
              ),
              TextField(controller: amount, keyboardType: TextInputType.number, decoration: const InputDecoration(labelText: 'Amount (PKR)')),
              TextField(controller: reference, decoration: const InputDecoration(labelText: 'Reference / Note')),
            ],
          ),
        ),
        actions: [
          TextButton(onPressed: () => Navigator.pop(context), child: const Text('Cancel')),
          FilledButton(
            onPressed: () async {
              final data = {
                if (existing?['id'] != null) 'id': existing!['id'].toString(),
                'party': party.text,
                'type': type,
                'amount': amount.text,
                'reference': reference.text,
                'created_by': widget.user['email'] ?? '',
              };
              await Api.paymentsSave(data);
              if (!mounted) return;
              Navigator.pop(context);
              _load();
            },
            child: const Text('Save'),
          ),
        ],
      ),
    );
  }

  Future<void> _delete(int id) async {
    final role = widget.user['role'] ?? 'staff';
    if (role != 'admin') return;
    await Api.paymentsDelete(id);
    _load();
  }

  @override
  void initState() {
    super.initState();
    _load();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Payments')),
      floatingActionButton: FloatingActionButton(onPressed: () => _addOrEdit(), child: const Icon(Icons.add)),
      body: ListView.separated(
        itemBuilder: (_, i) {
          final p = list[i];
          return ListTile(
            leading: Icon(p['type'] == 'incoming' ? Icons.south_west : Icons.north_east, color: p['type'] == 'incoming' ? Colors.green : Colors.red),
            title: Text('${p['party']} — PKR ${df.format((p['amount'] as num).toDouble())}'),
            subtitle: Text('${p['type']} • ${p['reference'] ?? ''}'),
            trailing: Row(
              mainAxisSize: MainAxisSize.min,
              children: [
                IconButton(onPressed: () => _addOrEdit(existing: p), icon: const Icon(Icons.edit)),
                if ((widget.user['role'] ?? 'staff') == 'admin') IconButton(onPressed: () => _delete(p['id'] as int), icon: const Icon(Icons.delete)),
              ],
            ),
          );
        },
        separatorBuilder: (_, __) => const Divider(height: 0),
        itemCount: list.length,
      ),
    );
  }
}
