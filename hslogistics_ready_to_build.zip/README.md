# HS Logistics — Final Package

This package contains:
- `app_flutter/` (Flutter app)
- `api_php/` (PHP API)

## API URL
Already configured to: https://hslogistics.pk/api

## Build the app
```
cd app_flutter
flutter pub get
flutter build apk --release
```
