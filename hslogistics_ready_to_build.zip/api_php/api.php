<?php
header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Headers: Content-Type');
header('Access-Control-Allow-Methods: POST, OPTIONS');
if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') { exit; }

require __DIR__.'/db.php';

$action = $_POST['action'] ?? '';

function ok($data=[]) { echo json_encode(['ok'=>true,'data'=>$data]); exit; }
function fail($msg) { echo json_encode(['ok'=>false,'error'=>$msg]); exit; }

if ($action === 'login') {
  $email = trim($_POST['email'] ?? '');
  $password = $_POST['password'] ?? '';
  if ($email === '') fail('Email required');

  $role = (str_ends_with(strtolower($email), '@hslogistics.pk')) ? 'admin' : 'staff';
  $name = explode('@',$email)[0];

  $stmt = $mysqli->prepare("INSERT INTO users (email,name,role) VALUES (?,?,?) ON DUPLICATE KEY UPDATE role=VALUES(role)");
  $stmt->bind_param('sss', $email, $name, $role);
  if (!$stmt->execute()) fail('User save failed: '.$stmt->error);

  ok(['user'=>['email'=>$email,'name'=>$name,'role'=>$role]]);
}

if ($action === 'payments_list') {
  $res = $mysqli->query("SELECT id, party, type, amount, date, reference, created_by FROM payments ORDER BY id DESC");
  $rows = [];
  while ($row = $res->fetch_assoc()) {
    $row['amount'] = (float)$row['amount'];
    $rows[] = $row;
  }
  ok($rows);
}

if ($action === 'payments_save') {
  $id = intval($_POST['id'] ?? 0);
  $party = $_POST['party'] ?? '';
  $type = $_POST['type'] ?? 'incoming';
  $amount = floatval($_POST['amount'] ?? 0);
  $reference = $_POST['reference'] ?? '';
  $created_by = $_POST['created_by'] ?? '';

  if ($id > 0) {
    $stmt = $mysqli->prepare("UPDATE payments SET party=?, type=?, amount=?, reference=?, created_by=? WHERE id=?");
    $stmt->bind_param('ssdssi', $party,$type,$amount,$reference,$created_by,$id);
  } else {
    $stmt = $mysqli->prepare("INSERT INTO payments (party,type,amount,reference,created_by) VALUES (?,?,?,?,?)");
    $stmt->bind_param('ssdss', $party,$type,$amount,$reference,$created_by);
  }
  if (!$stmt->execute()) fail('Payment save failed: '.$stmt->error);
  ok();
}

if ($action === 'payments_delete') {
  $id = intval($_POST['id'] ?? 0);
  if ($id <= 0) fail('Invalid id');
  $stmt = $mysqli->prepare("DELETE FROM payments WHERE id=?");
  $stmt->bind_param('i', $id);
  if (!$stmt->execute()) fail('Delete failed: '.$stmt->error);
  ok();
}

if ($action === 'bilties_list') {
  $res = $mysqli->query("SELECT id, vendor, vehicle, goods, from_city, to_city, km, amount, date, notes, created_by FROM bilties ORDER BY id DESC");
  $rows = [];
  while ($row = $res->fetch_assoc()) {
    $row['km'] = (float)$row['km'];
    $row['amount'] = (float)$row['amount'];
    $rows[] = $row;
  }
  ok($rows);
}

if ($action === 'bilties_save') {
  $id = intval($_POST['id'] ?? 0);
  $vendor = $_POST['vendor'] ?? '';
  $vehicle = $_POST['vehicle'] ?? '';
  $goods = $_POST['goods'] ?? '';
  $from_city = $_POST['from_city'] ?? '';
  $to_city = $_POST['to_city'] ?? '';
  $km = floatval($_POST['km'] ?? 0);
  $amount = floatval($_POST['amount'] ?? 0);
  $notes = $_POST['notes'] ?? '';
  $created_by = $_POST['created_by'] ?? '';

  if ($id > 0) {
    $stmt = $mysqli->prepare("UPDATE bilties SET vendor=?, vehicle=?, goods=?, from_city=?, to_city=?, km=?, amount=?, notes=?, created_by=? WHERE id=?");
    $stmt->bind_param('ssssssddsi', $vendor,$vehicle,$goods,$from_city,$to_city,$km,$amount,$notes,$created_by,$id);
  } else {
    $stmt = $mysqli->prepare("INSERT INTO bilties (vendor,vehicle,goods,from_city,to_city,km,amount,notes,created_by) VALUES (?,?,?,?,?,?,?,?,?)");
    $stmt->bind_param('ssssssdds', $vendor,$vehicle,$goods,$from_city,$to_city,$km,$amount,$notes,$created_by);
  }
  if (!$stmt || !$stmt->execute()) fail('Bilty save failed: '.$mysqli->error);
  ok();
}

if ($action === 'bilties_delete') {
  $id = intval($_POST['id'] ?? 0);
  if ($id <= 0) fail('Invalid id');
  $stmt = $mysqli->prepare("DELETE FROM bilties WHERE id=?");
  $stmt->bind_param('i', $id);
  if (!$stmt->execute()) fail('Delete failed: '.$stmt->error);
  ok();
}

fail('Unknown action');
?>
