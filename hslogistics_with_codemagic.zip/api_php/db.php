<?php
// db.php — Database connection
$DB_HOST = getenv('HS_DB_HOST') ?: 'localhost';
$DB_NAME = getenv('HS_DB_NAME') ?: 'hslogistics_fleet2';
$DB_USER = getenv('HS_DB_USER') ?: 'hslogistics_root';
$DB_PASS = getenv('HS_DB_PASS') ?: 'shazhad1234';
$DB_PORT = getenv('HS_DB_PORT') ?: '3306';

$mysqli = new mysqli($DB_HOST, $DB_USER, $DB_PASS, $DB_NAME, intval($DB_PORT));
if ($mysqli->connect_errno) {
    http_response_code(500);
    echo json_encode(['ok'=>false,'error'=>'DB connect error: '.$mysqli->connect_error]);
    exit;
}
$mysqli->set_charset('utf8mb4');
?>
