import 'package:flutter/material.dart';
import 'screens/login_screen.dart';
import 'screens/dashboard_screen.dart';
import 'screens/payments_screen.dart';
import 'screens/bilty_list_screen.dart';

void main() {
  runApp(const HSApp());
}

class HSApp extends StatelessWidget {
  const HSApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'HS Logistics',
      theme: ThemeData(
        colorSchemeSeed: const Color(0xFF1565C0),
        useMaterial3: true,
      ),
      debugShowCheckedModeBanner: false,
      initialRoute: '/',
      routes: {
        '/': (context) => const LoginScreen(),
        '/dashboard': (context) => const DashboardScreen(),
        '/payments': (context) => const PaymentsScreen(),
        '/bilty': (context) => const BiltyListScreen(),
      },
    );
  }
}
