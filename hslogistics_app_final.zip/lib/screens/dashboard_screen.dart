import 'package:flutter/material.dart';
import '../services/api_service.dart';

class DashboardScreen extends StatefulWidget {
  const DashboardScreen({super.key});

  @override
  State<DashboardScreen> createState() => _DashboardScreenState();
}

class _DashboardScreenState extends State<DashboardScreen> {
  final api = ApiService();
  int incoming = 0;
  int outgoing = 0;
  bool loading = true;
  String? error;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    try {
      final pays = await api.getPayments();
      int inSum = 0, outSum = 0;
      for (final p in pays) {
        final type = (p['type'] ?? 'in').toString().toLowerCase();
        final amt = int.tryParse((p['amount'] ?? '0').toString()) ?? 0;
        if (type == 'in') inSum += amt; else outSum += amt;
      }
      setState(() { incoming = inSum; outgoing = outSum; loading = false; });
    } catch (e) {
      setState(() { error = e.toString(); loading = false; });
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Dashboard')),
      body: loading ? const Center(child: CircularProgressIndicator()) :
        Padding(
          padding: const EdgeInsets.all(16),
          child: Column(
            children: [
              Row(
                children: [
                  _card('Incoming (PKR)', incoming.toString(), Icons.call_received),
                  const SizedBox(width: 12),
                  _card('Outgoing (PKR)', outgoing.toString(), Icons.call_made),
                ],
              ),
              const SizedBox(height: 16),
              Expanded(
                child: Row(
                  children: [
                    Expanded(child: _quickTile('Payments', Icons.account_balance_wallet, () {
                      Navigator.pushNamed(context, '/payments');
                    })),
                    const SizedBox(width: 12),
                    Expanded(child: _quickTile('Bilty / Vendors', Icons.local_shipping, () {
                      Navigator.pushNamed(context, '/bilty');
                    })),
                  ],
                ),
              )
            ],
          ),
        ),
    );
  }

  Expanded _card(String title, String value, IconData icon) {
    return Expanded(
      child: Card(
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
        child: Padding(
          padding: const EdgeInsets.all(16),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Icon(icon),
              const SizedBox(height: 8),
              Text(title, style: const TextStyle(fontWeight: FontWeight.bold)),
              const SizedBox(height: 6),
              Text(value, style: const TextStyle(fontSize: 22)),
            ],
          ),
        ),
      ),
    );
  }

  Widget _quickTile(String title, IconData icon, VoidCallback onTap) {
    return Card(
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
      child: InkWell(
        borderRadius: BorderRadius.circular(16),
        onTap: onTap,
        child: Padding(
          padding: const EdgeInsets.all(20),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Icon(icon, size: 40),
              const SizedBox(height: 10),
              Text(title, style: const TextStyle(fontSize: 16, fontWeight: FontWeight.w600)),
            ],
          ),
        ),
      ),
    );
  }
}
