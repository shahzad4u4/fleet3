import 'package:flutter/material.dart';
import '../services/api_service.dart';

class PaymentsScreen extends StatefulWidget {
  const PaymentsScreen({super.key});

  @override
  State<PaymentsScreen> createState() => _PaymentsScreenState();
}

class _PaymentsScreenState extends State<PaymentsScreen> {
  final api = ApiService();
  Future<List<dynamic>>? _future;

  @override
  void initState() {
    super.initState();
    _future = api.getPayments();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Payments')),
      body: FutureBuilder<List<dynamic>>(
        future: _future,
        builder: (context, snapshot) {
          if (snapshot.connectionState == ConnectionState.waiting) {
            return const Center(child: CircularProgressIndicator());
          }
          if (snapshot.hasError) {
            return Center(child: Text('Error: ${snapshot.error}'));
          }
          final data = snapshot.data ?? [];
          if (data.isEmpty) return const Center(child: Text('No payments found'));
          return ListView.separated(
            itemCount: data.length,
            separatorBuilder: (_, __) => const Divider(height: 1),
            itemBuilder: (context, i) {
              final p = data[i] as Map<String, dynamic>;
              return ListTile(
                leading: Icon((p['type'] ?? 'in') == 'in' ? Icons.call_received : Icons.call_made),
                title: Text('Amount: ${p['amount'] ?? '-'}'),
                subtitle: Text('Note: ${p['note'] ?? ''}'),
                trailing: Text((p['date'] ?? '').toString()),
              );
            },
          );
        },
      ),
    );
  }
}
