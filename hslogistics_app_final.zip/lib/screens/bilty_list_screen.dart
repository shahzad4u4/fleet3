import 'package:flutter/material.dart';
import '../services/api_service.dart';

class BiltyListScreen extends StatefulWidget {
  const BiltyListScreen({super.key});

  @override
  State<BiltyListScreen> createState() => _BiltyListScreenState();
}

class _BiltyListScreenState extends State<BiltyListScreen> {
  final api = ApiService();
  Future<List<dynamic>>? _future;

  @override
  void initState() {
    super.initState();
    _future = api.getBilty();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Bilty & Vendors')),
      body: FutureBuilder<List<dynamic>>(
        future: _future,
        builder: (context, snapshot) {
          if (snapshot.connectionState == ConnectionState.waiting) {
            return const Center(child: CircularProgressIndicator());
          }
          if (snapshot.hasError) {
            return Center(child: Text('Error: ${snapshot.error}'));
          }
          final data = snapshot.data ?? [];
          if (data.isEmpty) return const Center(child: Text('No bilty records'));
          return ListView.separated(
            itemCount: data.length,
            separatorBuilder: (_, __) => const Divider(height: 1),
            itemBuilder: (context, i) {
              final b = data[i] as Map<String, dynamic>;
              return ListTile(
                leading: const Icon(Icons.local_shipping),
                title: Text('Vendor: ${b['vendor'] ?? '-'}  |  Vehicle: ${b['vehicle'] ?? '-'}'),
                subtitle: Text('From: ${b['from'] ?? '-'}  →  To: ${b['to'] ?? '-'}  |  KM: ${b['km'] ?? '-'}'),
                trailing: Text('PKR ${b['amount'] ?? '-'}'),
              );
            },
          );
        },
      ),
    );
  }
}
