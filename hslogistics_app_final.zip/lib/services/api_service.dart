import 'dart:convert';
import 'package:http/http.dart' as http;
import '../config/api_config.dart';

class ApiService {
  final String _base = baseUrl;

  Future<Map<String, dynamic>> login(String email) async {
    final uri = Uri.parse("$_base/login");
    final res = await http.post(uri, body: {"email": email});
    if (res.statusCode == 200) {
      return jsonDecode(res.body) as Map<String, dynamic>;
    }
    throw Exception("Login failed (${res.statusCode})");
  }

  Future<List<dynamic>> getPayments() async {
    final uri = Uri.parse("$_base/payments");
    final res = await http.get(uri);
    if (res.statusCode == 200) {
      return jsonDecode(res.body) as List<dynamic>;
    }
    throw Exception("Payments fetch failed");
  }

  Future<List<dynamic>> getBilty() async {
    final uri = Uri.parse("$_base/bilty");
    final res = await http.get(uri);
    if (res.statusCode == 200) {
      return jsonDecode(res.body) as List<dynamic>;
    }
    throw Exception("Bilty fetch failed");
  }
}
