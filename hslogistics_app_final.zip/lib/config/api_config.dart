// Auto-generated API config
const String baseUrl = "https://hslogistics.pk/api";
