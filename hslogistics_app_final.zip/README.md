# HS Logistics — APK Build Ready

## API Base
App uses: `https://hslogistics.pk/api`

Expected endpoints (simple JSON):
- `POST /login`  -> { "ok": true, "role": "admin" | "staff" }
- `GET  /payments` -> [ { "type":"in"|"out", "amount":"12000", "note":"...", "date":"2025-08-01" } ]
- `GET  /bilty` -> [ { "vendor":"ABC", "vehicle":"LEA-123", "from":"Karachi", "to":"Lahore", "km":1200, "amount":45000 } ]

> Note: Flutter app does **not** connect to MySQL directly. It hits your hosted PHP API at `/api`.

## Build (Local)
```
flutter pub get
flutter create .   # if android/ios folders missing on fresh checkout
flutter build apk --release
```

## Build (Codemagic)
This project includes `codemagic.yaml`. Create a new app on codemagic.io and point to the repository.
Start the **build-android-apk** workflow.

## Customization
- Replace `assets/logo.png` with your real logo image.
- Change app name and package in `android/app/src/main/AndroidManifest.xml` after `flutter create .`

